
//*****************************************************************************
//
// Application Name     - int_sw
// Application Overview - The objective of this application is to demonstrate
//                          GPIO interrupts using SW2 and SW3.
//                          NOTE: the switches are not debounced!
//
//*****************************************************************************

//****************************************************************************
//
//! \addtogroup int_sw
//! @{
//
//****************************************************************************

// Standard includes
#include <stdio.h>
#include "string.h"

// Driverlib includes
#include "hw_types.h"
#include "hw_ints.h"
#include "hw_memmap.h"
#include "hw_common_reg.h"
#include "interrupt.h"
#include "hw_apps_rcm.h"
#include "prcm.h"
#include "rom.h"
#include "rom_map.h"
#include "prcm.h"
#include "gpio.h"
#include "utils.h"
#include "timer.h"
#include "systick.h"
#include "spi.h"
#include "uart.h"

// Common interface includes
#include "uart_if.h"
#include "pinmux.h"
#include "timer_if.h"
#include "gpio_if.h"

#define MASTER_MODE      1

#define SPI_IF_BIT_RATE  400000
#define TR_BUFF_SIZE     100
#define BLACK           0x0000
#define WHITE           0xFFFF

//*****************************************************************************
//                 GLOBAL VARIABLES -- Start
//*****************************************************************************
#if defined(ccs)
extern void (* const g_pfnVectors[])(void);
#endif
#if defined(ewarm)
extern uVectorEntry __vector_table;
#endif

volatile static tBoolean bRxDone;
long int coeff_array[7] = {31548, 31281, 30951, 30556, 29144, 28361, 27409};
long int power_all[7];
unsigned long A0TICK = (80000000 / 16000);
unsigned long A1TICK = 80000000;
unsigned char isSampling;
unsigned char isProcessing;
unsigned char isNewChar;
int isNew;
unsigned char UART_flag;
unsigned short sample_num;
int buf[400];//400
char Str4UART[60];
int new_digit = 0;
int maxLength;
int j;
signed int k;
int x;
int y;
int Rx;
int Ry;


char checkList[12][4] = {
                     {' '}, //Button 0
                     {',', '.', '!'}, //Button 1
                     {'a', 'b', 'c'}, //Button 2
                     {'d', 'e', 'f'}, //Button 3
                     {'g', 'h', 'i'}, //Button 4
                     {'j', 'k', 'l'}, //Button 5
                     {'m', 'n', 'o'}, //Button 6
                     {'p', 'q', 'r', 's'}, //Button 7
                     {'t', 'u', 'v'}, //Button 8
                     {'w', 'x', 'y', 'z'}, //Button 9
                     {'#'}, //Button # -> send
                     {'*'}, //Button * -> delete

};
//*****************************************************************************
//                 GLOBAL VARIABLES -- End
//*****************************************************************************


//****************************************************************************
//
//! Handler
//
//****************************************************************************

// Timer A0
// Used to control sampling
static void
TimerA0IntHandler(void)
{
    unsigned long ulStatus;
    ulStatus = MAP_TimerIntStatus(TIMERA0_BASE, true);
    MAP_TimerIntClear(TIMERA0_BASE, ulStatus);

    sample_num++;
    isSampling = 1;

    if (sample_num == 400)
        isProcessing = 1;
}

// Timer A1
// Used for inter-button
static void
TimerA1IntHandler(void)
{
    unsigned long ulStatus;
    ulStatus = MAP_TimerIntStatus(TIMERA1_BASE, true);
    MAP_TimerIntClear(TIMERA1_BASE, ulStatus);
    isNewChar = 1;
}

static void UARTIntHandler(void) {

    unsigned char transChar;
    MAP_UARTIntDisable(UARTA1_BASE,UART_INT_RX);

    while(UARTCharsAvail(UARTA1_BASE))
    {
        transChar = MAP_UARTCharGet(UARTA1_BASE);
        //printf("%c", transChar);
        if(isNew)
        {
            fillRect(0, 65, 127, 127, BLACK);
            isNew = 0;
        }

        if(Rx > 127) // About to go off right edge.
        {
            Rx = 0;
            Ry += 8; // go to next line.
        }
        if(transChar == '\0')
        {
            //printf("\n\n");
            isNew = 1;
            Rx = 0;
            Ry = 65;
        }
        else
        {
            drawChar(Rx, Ry, transChar, WHITE, BLACK, 1);
            Rx += 8;
        }
    }
    MAP_UARTIntClear(UARTA1_BASE,UART_INT_RX);
    MAP_UARTIntEnable(UARTA1_BASE,UART_INT_RX);
}
//*****************************************************************************
//                      LOCAL FUNCTION PROTOTYPES
//*****************************************************************************
static void BoardInit(void);


//*****************************************************************************
//
//! Board Initialization & Configuration
//!
//! \param  None
//!
//! \return None
//
//*****************************************************************************
static void
BoardInit(void) {
    /* In case of TI-RTOS vector table is initialize by OS itself */
    #ifndef USE_TIRTOS
      //
      // Set vector table base
      //
    #if defined(ccs)
        MAP_IntVTableBaseSet((unsigned long)&g_pfnVectors[0]);
    #endif
    #if defined(ewarm)
        MAP_IntVTableBaseSet((unsigned long)&__vector_table);
    #endif
    #endif

    // Enable Processor
    //
    MAP_IntMasterEnable();
    MAP_IntEnable(FAULT_SYSTICK);

    PRCMCC3200MCUInit();
}
//****************************************************************************
//
// Init
//
//****************************************************************************
static void SPI_Init(void)
{
    // Enable the SPI module clock
    MAP_PRCMPeripheralClkEnable(PRCM_GSPI,PRCM_RUN_MODE_CLK);

    // Reset the peripheral
    MAP_PRCMPeripheralReset(PRCM_GSPI);

    // Reset SPI
    MAP_SPIReset(GSPI_BASE);

    // Configure SPI interface
    MAP_SPIConfigSetExpClk(GSPI_BASE,MAP_PRCMPeripheralClockGet(PRCM_GSPI),
                           SPI_IF_BIT_RATE,SPI_MODE_MASTER,SPI_SUB_MODE_0,
                           (SPI_SW_CTRL_CS |
                           SPI_4PIN_MODE |
                           SPI_TURBO_OFF |
                           SPI_CS_ACTIVEHIGH |
                           SPI_WL_8));

    MAP_SPIEnable(GSPI_BASE);
}


static void Timer_Init(void)
{
    unsigned long ulStatus;
    // Init Timer A0
    PRCMPeripheralClkEnable(PRCM_TIMERA0, PRCM_RUN_MODE_CLK);
    PRCMPeripheralReset(PRCM_TIMERA0);
    TimerIntRegister(TIMERA0_BASE, TIMER_A, TimerA0IntHandler);
    TimerConfigure(TIMERA0_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMERA0_BASE, TIMER_A, A0TICK);
    ulStatus = TimerIntStatus(TIMERA0_BASE, false);
    TimerIntClear(TIMERA0_BASE, ulStatus);

    // Init Timer A1
    PRCMPeripheralClkEnable(PRCM_TIMERA1, PRCM_RUN_MODE_CLK);
    PRCMPeripheralReset(PRCM_TIMERA1);
    TimerIntRegister(TIMERA1_BASE, TIMER_A, TimerA1IntHandler);
    TimerConfigure(TIMERA1_BASE, TIMER_CFG_ONE_SHOT);
    TimerLoadSet(TIMERA1_BASE, TIMER_A, A1TICK);
    ulStatus = TimerIntStatus(TIMERA1_BASE, false);
    TimerIntClear(TIMERA1_BASE, ulStatus);
}

void UART_Setup(void)
{
    MAP_UARTConfigSetExpClk(UARTA1_BASE,MAP_PRCMPeripheralClockGet(PRCM_UARTA1),
                          115200, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |
                           UART_CONFIG_PAR_NONE));
    MAP_UARTIntRegister(UARTA1_BASE,UARTIntHandler);
}

//****************************************************************************
//
//! Function
//
//****************************************************************************
unsigned short
readExternalADC(void)
{
    unsigned char data0;
    unsigned char data1;
    GPIOPinWrite(GPIOA1_BASE, 0x40, 0x00);
    MAP_SPITransfer(GSPI_BASE, 0, &data0, 0x1, SPI_CS_ENABLE);
    MAP_SPITransfer(GSPI_BASE, 0, &data1, 0x1, SPI_CS_DISABLE);
    GPIOPinWrite(GPIOA1_BASE, 0x40, 0x40);
    unsigned short data = 0x1f & data0;
    data = (data << 5) | ((0xf8 & data1) >> 3);
    return data;
}

long int goertzel(long int coeff)
{
    //initialize variables to be used in the function
    int Q, Q_prev, Q_prev2,i;
    long prod1,prod2,prod3,power;

    Q_prev = 0;         //set delay element1 Q_prev as zero
    Q_prev2 = 0;        //set delay element2 Q_prev2 as zero
    power=0;            //set power as zero

    for (i=0; i<400; i++) // loop SAMPLE_SPACE times and calculate Q, Q_prev, Q_prev2 at each iteration
        {
            Q = (buf[i]) + ((coeff* Q_prev)>>14) - (Q_prev2); // >>14 used as the coeff was used in Q15 format
            Q_prev2 = Q_prev;                                    // shuffle delay elements
            Q_prev = Q;
        }

    //calculate the three products used to calculate power
    prod1=((long) Q_prev*Q_prev);
    prod2=((long) Q_prev2*Q_prev2);
    prod3=((long) Q_prev *coeff)>>14;
    prod3=(prod3 * Q_prev2);

    power = ((prod1+prod2-prod3))>>8; //calculate power using the three products and scale the result down

    return power;
}

char decode(void) // post_test() function from the Github example
{
    //initialize variables to be used in the function
    int max_power,i, row, col;

    char buttonList[4][4] = {
        {'1', '2', '3', 'A'},
        {'4', '5', '6', 'B'},
        {'7', '8', '9', 'C'},
        {'*', '0', '#', 'D'},
    };

    // find the maximum power in the row frequencies and the row number
    max_power=0;            //initialize max_power=0
    for(i=0;i<4;i++) {      //loop 4 times from 0>3 (the indecies of the rows)
        if (power_all[i] > max_power) { //if power of the current row frequency > max_power
            max_power=power_all[i];     //set max_power as the current row frequency
            row=i;                      //update row number
        }
    }

    // find the maximum power in the column frequencies and the column number
    max_power=0;            //initialize max_power=0
    for(i=4;i<7;i++) {      //loop 3 times from 4>7 (the indecies of the columns)
        if (power_all[i] > max_power) { //if power of the current column frequency > max_power
            max_power=power_all[i];     //set max_power as the0 current column frequency
            col=i;                      //update column number
        }
    }

    if(power_all[col]<=10 && power_all[row]<=10) //instead 0 in the original example, set a threshold to avoid noise in the lab
        new_digit = 1;

    if((power_all[col]>70 && power_all[row]>70) && (new_digit == 1)) { // check if maximum powers of row & column exceed certain threshold
        new_digit = 0;
        col -= 4;
        return buttonList[row][col];
    }

    return 'x';
}

static int
rowCheck(char text) {
    int message;
    if(text == '0') { message = 0; maxLength = 0;}
    else if(text == '1') { message = 1; maxLength = 2;}
    else if(text == '2') { message = 2; maxLength = 2;}
    else if(text == '3') { message = 3; maxLength = 2;}
    else if(text == '4') { message = 4; maxLength = 2;}
    else if(text == '5') { message = 5; maxLength = 2;}
    else if(text == '6') { message = 6; maxLength = 2;}
    else if(text == '7') { message = 7; maxLength = 3;}
    else if(text == '8') { message = 8; maxLength = 2;}
    else if(text == '9') { message = 9; maxLength = 3;}
    else if(text == '#') { message = 10; maxLength = 0;}
    else if(text == '*') { message = 11; maxLength = 0;}
    else{message = 12;}

    return message;
}

static void Char2OLED(signed char newChar, signed char oldChar)
{
    int i = rowCheck(newChar);
    int n;
    char input;
    if(newChar == '*'){
        Str4UART[k] = '\0';
        k--;
        drawChar(x, y, ' ', WHITE, BLACK, 1);
        x -= 8;
        if (x == 0 && y >= 8) {
          x = 119;
          y -= 8;
        }
        if (x <= 3 && y <= 3) {
          x = 0;
          y = 0;
        }
    }
    else if(newChar == '#'){
        fillRect(0, 0, 127, 63, BLACK);
        Str4UART[k] = '\0';
        printf("K ---> %d\n", k);
        printf("WTF %s\n", Str4UART);
        for(n = 0; n <= strlen(Str4UART); n++){
            printf("%c", Str4UART[n]);
            MAP_UARTCharPut(UARTA1_BASE, Str4UART[n]);
        }
        printf("\n\n");
        x = 0;
        y = 0;
        k = -1;
    }

    if(newChar != 'x' && newChar != '#' && newChar != '*'){
        if(newChar == oldChar && j < maxLength){
            j++;
        }
        drawChar(x, y, checkList[i][j], WHITE, BLACK, 1);
        input = checkList[i][j];
        Str4UART[k] = input;
        printf("#%d: input => %c\n", k, Str4UART[k]);
        //printf("last => %c\n", Str4UART[k-1]);
    }
}
//****************************************************************************
//
//! Main function
//!
//! \param none
//!
//!
//! \return None.
//
//****************************************************************************


int main() {
    // Initializations
    BoardInit();
    PinMuxConfig();
    SPI_Init();
    Timer_Init();
    UART_Setup();

    Adafruit_Init();
    fillScreen(BLACK);
    drawLine(0, 64, 127, 64, WHITE);

    InitTerm();
    ClearTerm();

    Message("\t\t****************************************************\n\r");
    Message("\t\t\t IR Remote TX/RX Application Start \n\r");
    Message("\t\t ****************************************************\n\r");
    Message("\n\n\n\r");

    // variable setups
    unsigned long ulStatus;
    char newChar = 'x';
    char oldChar = 'x';
    int i;
    j = 0;
    k = -1;
    x = 0;
    y = 0;
    Rx = 0;
    Ry = 0;
    isNew = 1;

    isSampling = 0;
    isNewChar = 0;
    isProcessing = 0;
    sample_num = 0;

    ulStatus = MAP_UARTIntStatus(TIMERA1_BASE, true);
    MAP_UARTIntClear(TIMERA1_BASE, ulStatus);

    MAP_UARTIntEnable(UARTA1_BASE,UART_INT_RX|UART_INT_RT);
    MAP_UARTEnable(UARTA1_BASE);
    TimerIntEnable(TIMERA0_BASE, TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMERA0_BASE, TIMER_A);


    //?
    MAP_TimerLoadSet(TIMERA1_BASE, TIMER_A, A1TICK);
    MAP_TimerIntEnable(TIMERA1_BASE, TIMER_A);
    MAP_TimerEnable(TIMERA1_BASE, TIMER_TIMA_TIMEOUT);

    while (1) {
        if (isSampling == 1) {
            isSampling = 0;
            // 1024*V_bias/V_ref = 1024*1.2/3.3 = 372
            buf[sample_num-1] = (int) readExternalADC();
        }
        if (isProcessing == 1) {
            // disable sampling timer
            MAP_TimerDisable(TIMERA0_BASE, TIMER_A);
            MAP_TimerIntDisable(TIMERA0_BASE, TIMER_TIMA_TIMEOUT);
            unsigned long ulStatus;
            ulStatus = MAP_TimerIntStatus(TIMERA0_BASE, false);
            MAP_TimerIntClear(TIMERA0_BASE, ulStatus);

            // reset state variables
            isProcessing = 0;
            sample_num = 0;


            for (i = 0; i < 7; i++)
                power_all[i] = goertzel(coeff_array[i]) >> 13;

            newChar = decode();
            //print the pressed button on console
            if(newChar != 'x'){
                printf("### %c\n", newChar);
                printf("------------------------------\n");
            }

            if (newChar > 0 && newChar != 'x') {
                MAP_TimerDisable(TIMERA1_BASE, TIMER_A);
                MAP_TimerIntDisable(TIMERA1_BASE, TIMER_TIMA_TIMEOUT);
                // disable
                if((newChar != oldChar || isNewChar == 1) && newChar != '*'){
                    k++;
                    j = 0;
                    oldChar = 'x';

                    x+=8;
                    if(x > 127){
                        x = 0;
                        y+=8;
                        if(y > 127)
                            y = 0;
                    }
                }
                //printf("check NEW %c \n", newChar);
                Char2OLED(newChar, oldChar);
                isNewChar = 0;
                oldChar = newChar;
                //printf("check OLD %c \n\n", oldChar);

                MAP_TimerLoadSet(TIMERA1_BASE, TIMER_A, A1TICK);
                MAP_TimerIntEnable(TIMERA1_BASE, TIMER_A);
                MAP_TimerEnable(TIMERA1_BASE, TIMER_TIMA_TIMEOUT);
            }
            // Re-enable sampling timer
            MAP_TimerLoadSet(TIMERA0_BASE, TIMER_A, A0TICK);
            MAP_TimerIntEnable(TIMERA0_BASE, TIMER_A);
            MAP_TimerEnable(TIMERA0_BASE, TIMER_TIMA_TIMEOUT);
        }
    }
}

//*****************************************************************************
//
// Close the Doxygen group.
//! @}
//
//*****************************************************************************
